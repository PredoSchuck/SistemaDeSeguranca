package com.example.validator;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.jupiter.params.provider.MethodSource;

import org.junit.runner.RunWith;
import org.junit.platform.runner.JUnitPlatform;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(JUnitPlatform.class)
public class ValidatorTest {

    @Nested
    @DisplayName("Email validation")
    class EmailTests {
        @ParameterizedTest
        @ValueSource(strings = {
                "user@example.com",
                "user.name+tag+sorting@example.co.uk",
                "user_name@example.io",
                "user-name@example.org"
        })
        void validEmails(String email) {
            assertTrue(Validator.isEmailValid(email));
        }

        @ParameterizedTest
        @NullAndEmptySource
        @ValueSource(strings = {
                "plainaddress",
                "@no-local-part.com",
                "no-at.domain.com",
                "user@.com",
                "user@com"
        })
        void invalidEmails(String email) {
            assertFalse(Validator.isEmailValid(email));
        }

        @Test
        void nullEmailIsInvalid() {
            assertFalse(Validator.isEmailValid(null));
        }
    }

    @Nested
    @DisplayName("Phone validation")
    class PhoneTests {
        @ParameterizedTest
        @ValueSource(strings = {
                "+55 11 91234-5678",
                "(11) 91234-5678",
                "11 912345678",
                "11912345678",
                "0123456789",
                "1112345678"
        })
        void validPhones(String phone) {
            assertTrue(Validator.isPhoneValid(phone));
        }

        @ParameterizedTest
        @NullAndEmptySource
        @ValueSource(strings = {
                "123", "abcdefgh", "++55 11 91234-5678"
        })
        void invalidPhones(String phone) {
            assertFalse(Validator.isPhoneValid(phone));
        }
    }

    @Nested
    @DisplayName("Password validation")
    class PasswordTests {
        @ParameterizedTest
        @ValueSource(strings = {
                "Abcdef1!",
                "Str0ng#Pass",
                "P@ssw0rdA"
        })
        void validPasswords(String pwd) {
            assertTrue(Validator.isStrongPassword(pwd));
        }

        @ParameterizedTest
        @NullAndEmptySource
        @ValueSource(strings = {
                "short1!",
                "alllowercase1!",
                "ALLUPPERCASE1!",
                "NoDigits!!",
                "NoSpecial123"
        })
        void invalidPasswords(String pwd) {
            assertFalse(Validator.isStrongPassword(pwd));
        }

        @Test
        void nullPasswordIsInvalid() {
            assertFalse(Validator.isStrongPassword(null));
        }
    }

    @Nested
    @DisplayName("CPF validation")
    class CPFTests {
        static Stream<Object[]> cpfProvider() {
            return Stream.of(
                new Object[]{"11144477735", true},
                new Object[]{"52998224725", true},
                new Object[]{"12345678909", true},
                new Object[]{"00000000000", false},
                new Object[]{"", false},
                new Object[]{null, false}
            );
        }

        @ParameterizedTest
        @MethodSource("cpfProvider")
        void cpfCases(String input, boolean expected) {
            assertEquals(expected, Validator.isCPFValid(input));
        }

        @Test
        void cpfWithFormatting() {
            String cpfFormatted = "529.982.247-25";
            assertTrue(Validator.isCPFValid(cpfFormatted));
        }
    }
}