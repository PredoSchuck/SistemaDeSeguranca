package com.example.validator;

import java.util.regex.Pattern;

public final class Validator {

    private Validator() {}
    
    private static final Pattern EMAIL = Pattern.compile(
            "^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}$"
    );

    private static final Pattern PHONE = Pattern.compile(
            "^(?:\\+55\\s?)?(?:\\(?0?\\d{2}\\)?[\\s-]?)?\\d{4,5}[\\s-]?\\d{4}$"
    );
    
    private static final Pattern STRONG_PASSWORD = Pattern.compile(
            "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}$"
    );

    public static boolean isEmailValid(String email) {
        if (email == null) return false;
        email = email.trim();
        if (email.isEmpty()) return false;
        return EMAIL.matcher(email).matches();
    }

    public static boolean isPhoneValid(String phone) {
        if (phone == null) return false;
        phone = phone.trim();
        if (phone.isEmpty()) return false;
        return PHONE.matcher(phone).matches();
    }

    public static boolean isStrongPassword(String password) {
        if (password == null) return false;
        password = password.trim();
        if (password.isEmpty()) return false;
        return STRONG_PASSWORD.matcher(password).matches();
    }

    public static boolean isCPFValid(String cpf) {
        if (cpf == null) return false;
        String onlyDigits = cpf.replaceAll("\\D", "");
        if (onlyDigits.length() != 11) return false;

        if (onlyDigits.matches("(\\d)\\1{10}")) return false;

        try {
            int[] nums = new int[11];
            for (int i = 0; i < 11; i++) {
                nums[i] = Character.getNumericValue(onlyDigits.charAt(i));
            }

            int sum1 = 0;
            for (int i = 0; i < 9; i++) {
                sum1 += nums[i] * (10 - i);
            }
            int rem1 = sum1 % 11;
            int dig1 = (rem1 < 2) ? 0 : 11 - rem1;
            if (dig1 != nums[9]) return false;

            int sum2 = 0;
            for (int i = 0; i < 10; i++) {
                sum2 += nums[i] * (11 - i);
            }
            int rem2 = sum2 % 11;
            int dig2 = (rem2 < 2) ? 0 : 11 - rem2;
            return dig2 == nums[10];
        } catch (Exception e) {
            return false;
        }
    }
}