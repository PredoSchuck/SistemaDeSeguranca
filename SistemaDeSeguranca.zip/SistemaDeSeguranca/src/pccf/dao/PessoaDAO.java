package pccf.dao;

import pccf.connection.Conexao;
import pccf.model.Pessoa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;


public class PessoaDAO {

    public void inserir(Pessoa p) {
        String sql = "INSERT INTO pessoa (nome, cpf, rg, data_nascimento, telefone, tipo) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getCpf());
            stmt.setString(3, p.getRg());
            stmt.setDate(4, Date.valueOf(p.getDataNascimento()));
            stmt.setString(5, p.getTelefone());
            stmt.setString(6, p.getTipo());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir pessoa", e);
        }
    }

    public List<Pessoa> listar() {
        List<Pessoa> pessoas = new ArrayList<>();
        String sql = "SELECT * FROM pessoa";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Pessoa p = new Pessoa();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setCpf(rs.getString("cpf"));
                p.setRg(rs.getString("rg"));
                p.setDataNascimento(rs.getDate("data_nascimento").toLocalDate());
                p.setTelefone(rs.getString("telefone"));
                p.setTipo(rs.getString("tipo"));
                pessoas.add(p);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir pessoa", e);
        }

        return pessoas;
    }

    public void atualizar(Pessoa p) {
        String sql = "UPDATE pessoa SET nome=?, cpf=?, rg=?, data_nascimento=?, telefone=?, tipo=? WHERE id=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getCpf());
            stmt.setString(3, p.getRg());
            stmt.setDate(4, Date.valueOf(p.getDataNascimento()));
            stmt.setString(5, p.getTelefone());
            stmt.setString(6, p.getTipo());
            stmt.setInt(7, p.getId());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir pessoa", e);
        }
    }

    public void excluir(int id) {
        String sql = "DELETE FROM pessoa WHERE id=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir pessoa", e);
        }
    }

    public List<Pessoa> buscarPorNome(String nome) {
        List<Pessoa> pessoas = new ArrayList<>();
        String sql = "SELECT * FROM pessoa WHERE nome LIKE ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "%" + nome + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Pessoa p = new Pessoa();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setCpf(rs.getString("cpf"));
                p.setRg(rs.getString("rg"));
                p.setDataNascimento(rs.getDate("data_nascimento").toLocalDate());
                p.setTelefone(rs.getString("telefone"));
                p.setTipo(rs.getString("tipo"));
                pessoas.add(p);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir pessoa", e);
        }

        return pessoas;
    }
}