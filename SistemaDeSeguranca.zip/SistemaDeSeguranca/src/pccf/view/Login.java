package pccf.view;

import javax.swing.JOptionPane;
import pccf.dao.UsuarioDAO;

public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTxtMainTitulo = new javax.swing.JLabel();
        jTxtFieldUsuario = new javax.swing.JTextField();
        jTxtUsuario = new javax.swing.JLabel();
        jTxtSenha = new javax.swing.JLabel();
        jTxtFieldSenha = new javax.swing.JTextField();
        jBttLogin = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jTxtMainTitulo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jTxtMainTitulo.setText("Prédio Comercial Centro Farroupilha");
        jTxtMainTitulo.setPreferredSize(new java.awt.Dimension(420, 30));

        jTxtFieldUsuario.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTxtFieldUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtFieldUsuarioActionPerformed(evt);
            }
        });

        jTxtUsuario.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jTxtUsuario.setText("Usuário:");

        jTxtSenha.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jTxtSenha.setText("Senha:");

        jTxtFieldSenha.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jTxtFieldSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtFieldSenhaActionPerformed(evt);
            }
        });

        jBttLogin.setBackground(new java.awt.Color(204, 204, 204));
        jBttLogin.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jBttLogin.setText("Login");
        jBttLogin.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jBttLogin.setName(""); // NOI18N
        jBttLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBttLoginActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTxtMainTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(61, 61, 61)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jTxtSenha)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTxtFieldSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jTxtUsuario)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTxtFieldUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGap(125, 125, 125)
                            .addComponent(jBttLogin)
                            .addGap(98, 98, 98)))
                    .addContainerGap(61, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jTxtMainTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(200, 200, 200))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(73, 73, 73)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTxtFieldUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTxtUsuario))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jTxtFieldSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTxtSenha))
                    .addGap(18, 18, 18)
                    .addComponent(jBttLogin)
                    .addContainerGap(73, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTxtFieldUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtFieldUsuarioActionPerformed
//
    }//GEN-LAST:event_jTxtFieldUsuarioActionPerformed

    private void jTxtFieldSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtFieldSenhaActionPerformed
//
    }//GEN-LAST:event_jTxtFieldSenhaActionPerformed

    private void jBttLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBttLoginActionPerformed
    try {
        String usuario = jTxtFieldUsuario.getText().trim();
        String senha = jTxtFieldSenha.getText().trim();
        if (usuario.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha usuário e senha!");
            return;
        }

        UsuarioDAO dao = new UsuarioDAO();
        boolean autenticado = dao.autenticar(usuario, senha);

        if (autenticado) {
            new Menu().setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Usuário ou senha inválidos.");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Erro ao autenticar: " + e.getMessage());
    }
    }//GEN-LAST:event_jBttLoginActionPerformed

    public static void main(String args[]) {
        new Login().setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBttLogin;
    private javax.swing.JTextField jTxtFieldSenha;
    private javax.swing.JTextField jTxtFieldUsuario;
    private javax.swing.JLabel jTxtMainTitulo;
    private javax.swing.JLabel jTxtSenha;
    private javax.swing.JLabel jTxtUsuario;
    // End of variables declaration//GEN-END:variables
}
