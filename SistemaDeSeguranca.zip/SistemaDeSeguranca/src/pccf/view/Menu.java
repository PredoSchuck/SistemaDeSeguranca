package pccf.view;

public class Menu extends javax.swing.JFrame {

    public Menu() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jBttCadastrarPessoa = new javax.swing.JButton();
        jBttCadastrarUsuario = new javax.swing.JButton();
        jBttSair = new javax.swing.JButton();
        jTxtMainTitulo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jBttCadastrarPessoa.setBackground(new java.awt.Color(204, 204, 204));
        jBttCadastrarPessoa.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jBttCadastrarPessoa.setText("Cadastrar Pessoa");
        jBttCadastrarPessoa.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jBttCadastrarPessoa.setName(""); // NOI18N
        jBttCadastrarPessoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBttCadastrarPessoaActionPerformed(evt);
            }
        });

        jBttCadastrarUsuario.setBackground(new java.awt.Color(204, 204, 204));
        jBttCadastrarUsuario.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jBttCadastrarUsuario.setText("Cadastrar Usuário");
        jBttCadastrarUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jBttCadastrarUsuario.setName(""); // NOI18N
        jBttCadastrarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBttCadastrarUsuarioActionPerformed(evt);
            }
        });

        jBttSair.setBackground(new java.awt.Color(204, 204, 204));
        jBttSair.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jBttSair.setText("Sair");
        jBttSair.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jBttSair.setName(""); // NOI18N
        jBttSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBttSairActionPerformed(evt);
            }
        });

        jTxtMainTitulo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jTxtMainTitulo.setText("Prédio Comercial Centro Farroupilha");
        jTxtMainTitulo.setPreferredSize(new java.awt.Dimension(420, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jBttSair, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBttCadastrarPessoa, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBttCadastrarUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTxtMainTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jTxtMainTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jBttCadastrarPessoa)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBttCadastrarUsuario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBttSair)
                .addGap(68, 68, 68))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBttCadastrarPessoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBttCadastrarPessoaActionPerformed
        new CadastrarPessoa().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jBttCadastrarPessoaActionPerformed

    private void jBttCadastrarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBttCadastrarUsuarioActionPerformed
        new CadastrarUsuario().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jBttCadastrarUsuarioActionPerformed

    private void jBttSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBttSairActionPerformed
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jBttSairActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBttCadastrarPessoa;
    private javax.swing.JButton jBttCadastrarUsuario;
    private javax.swing.JButton jBttSair;
    private javax.swing.JLabel jTxtMainTitulo;
    // End of variables declaration//GEN-END:variables
}
