package pccf.view;

import javax.swing.JOptionPane;
import pccf.dao.UsuarioDAO;
import pccf.model.Usuario;

public class CadastrarUsuario extends javax.swing.JFrame {

    public CadastrarUsuario() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTxtMainTitulo = new javax.swing.JLabel();
        jTxtUsuario = new javax.swing.JLabel();
        jTxtSenha = new javax.swing.JLabel();
        jTxtCSenha = new javax.swing.JLabel();
        jTxtFieldUsuario = new javax.swing.JTextField();
        jTxtFieldSenha = new javax.swing.JTextField();
        jTxtFieldCSenha = new javax.swing.JTextField();
        jBttConcluir = new javax.swing.JButton();
        jBttCancelar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jTxtMainTitulo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jTxtMainTitulo.setText("Prédio Comercial Centro Farroupilha");
        jTxtMainTitulo.setPreferredSize(new java.awt.Dimension(420, 30));

        jTxtUsuario.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtUsuario.setText("Usuário:");

        jTxtSenha.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtSenha.setText("Senha:");

        jTxtCSenha.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtCSenha.setText("Confirme sua senha:");

        jTxtFieldUsuario.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtFieldUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtFieldUsuarioActionPerformed(evt);
            }
        });

        jTxtFieldSenha.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtFieldSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtFieldSenhaActionPerformed(evt);
            }
        });

        jTxtFieldCSenha.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtFieldCSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtFieldCSenhaActionPerformed(evt);
            }
        });

        jBttConcluir.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jBttConcluir.setText("Concluir");
        jBttConcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBttConcluirActionPerformed(evt);
            }
        });

        jBttCancelar1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jBttCancelar1.setText("Cancelar");
        jBttCancelar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBttCancelar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jTxtMainTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jBttCancelar1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jBttConcluir)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTxtSenha)
                            .addComponent(jTxtUsuario)
                            .addComponent(jTxtCSenha))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTxtFieldUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxtFieldSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxtFieldCSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTxtMainTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtUsuario)
                    .addComponent(jTxtFieldUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtSenha)
                    .addComponent(jTxtFieldSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtCSenha)
                    .addComponent(jTxtFieldCSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(59, 59, 59)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBttConcluir)
                    .addComponent(jBttCancelar1))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBttConcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBttConcluirActionPerformed
        String usuario = jTxtFieldUsuario.getText().trim();
    String senha = jTxtFieldSenha.getText().trim();
    String csenha = jTxtFieldCSenha.getText().trim();

    if (usuario.isEmpty() || senha.isEmpty() || csenha.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Preencha todos os campos!");
        return;
    }

    if (!senha.equals(csenha)) {
        JOptionPane.showMessageDialog(this, "As senhas não coincidem!");
        return;
    }

    Usuario u = new Usuario();
    u.setUsuario(usuario);
    u.setSenha(senha);

    UsuarioDAO dao = new UsuarioDAO();
    try {
        dao.inserir(u);
        JOptionPane.showMessageDialog(this, "Usuário cadastrado com sucesso!");
        jTxtFieldUsuario.setText("");
        jTxtFieldSenha.setText("");
        jTxtFieldCSenha.setText("");
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Erro ao cadastrar usuário: " + e.getMessage());
    }
    }//GEN-LAST:event_jBttConcluirActionPerformed

    private void jBttCancelar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBttCancelar1ActionPerformed
        new Menu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jBttCancelar1ActionPerformed

    private void jTxtFieldUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtFieldUsuarioActionPerformed
//
    }//GEN-LAST:event_jTxtFieldUsuarioActionPerformed

    private void jTxtFieldCSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtFieldCSenhaActionPerformed
//
    }//GEN-LAST:event_jTxtFieldCSenhaActionPerformed

    private void jTxtFieldSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtFieldSenhaActionPerformed
//
    }//GEN-LAST:event_jTxtFieldSenhaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBttCancelar1;
    private javax.swing.JButton jBttConcluir;
    private javax.swing.JLabel jTxtCSenha;
    private javax.swing.JTextField jTxtFieldCSenha;
    private javax.swing.JTextField jTxtFieldSenha;
    private javax.swing.JTextField jTxtFieldUsuario;
    private javax.swing.JLabel jTxtMainTitulo;
    private javax.swing.JLabel jTxtSenha;
    private javax.swing.JLabel jTxtUsuario;
    // End of variables declaration//GEN-END:variables
}