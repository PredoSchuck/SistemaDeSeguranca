package pccf.view;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import pccf.model.Pessoa;
import pccf.dao.PessoaDAO;
        
public class CadastrarPessoa extends javax.swing.JFrame {

    public CadastrarPessoa() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jBttGroupTipo = new javax.swing.ButtonGroup();
        jTxtMainTitulo = new javax.swing.JLabel();
        jTxtNome = new javax.swing.JLabel();
        jTxtCPF = new javax.swing.JLabel();
        jTxtRG = new javax.swing.JLabel();
        jTxtDtNascimento = new javax.swing.JLabel();
        jTxtTelefone = new javax.swing.JLabel();
        jTxtFieldNome = new javax.swing.JTextField();
        jTxtFieldRG = new javax.swing.JTextField();
        jBttMarcarFuncionario = new javax.swing.JRadioButton();
        jBttMarcarInquilino = new javax.swing.JRadioButton();
        jBttMarcarVisitante = new javax.swing.JRadioButton();
        jBttConcluir = new javax.swing.JButton();
        jBttCancelar = new javax.swing.JButton();
        jFormattedTxtCPF = new javax.swing.JFormattedTextField();
        jFormattedTxtDtNascimento = new javax.swing.JFormattedTextField();
        jFormattedTxtTelefone = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jTxtMainTitulo.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jTxtMainTitulo.setText("Prédio Comercial Centro Farroupilha");
        jTxtMainTitulo.setPreferredSize(new java.awt.Dimension(420, 30));

        jTxtNome.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtNome.setText("Nome:");

        jTxtCPF.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtCPF.setText("CPF:");

        jTxtRG.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtRG.setText("RG:");

        jTxtDtNascimento.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtDtNascimento.setText("Dt. Nascimento:");

        jTxtTelefone.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtTelefone.setText("Telefone:");

        jTxtFieldNome.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtFieldNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtFieldNomeActionPerformed(evt);
            }
        });

        jTxtFieldRG.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jTxtFieldRG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtFieldRGActionPerformed(evt);
            }
        });

        jBttGroupTipo.add(jBttMarcarFuncionario);
        jBttMarcarFuncionario.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jBttMarcarFuncionario.setText("Funcionário");
        jBttMarcarFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBttMarcarFuncionarioActionPerformed(evt);
            }
        });

        jBttGroupTipo.add(jBttMarcarInquilino);
        jBttMarcarInquilino.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jBttMarcarInquilino.setText("Inquilino");
        jBttMarcarInquilino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBttMarcarInquilinoActionPerformed(evt);
            }
        });

        jBttGroupTipo.add(jBttMarcarVisitante);
        jBttMarcarVisitante.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jBttMarcarVisitante.setText("Visitante");
        jBttMarcarVisitante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBttMarcarVisitanteActionPerformed(evt);
            }
        });

        jBttConcluir.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jBttConcluir.setText("Concluir");
        jBttConcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBttConcluirActionPerformed(evt);
            }
        });

        jBttCancelar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jBttCancelar.setText("Cancelar");
        jBttCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBttCancelarActionPerformed(evt);
            }
        });

        try {
            jFormattedTxtCPF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jFormattedTxtCPF.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jFormattedTxtCPF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTxtCPFActionPerformed(evt);
            }
        });

        try {
            jFormattedTxtDtNascimento.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jFormattedTxtDtNascimento.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jFormattedTxtDtNascimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTxtDtNascimentoActionPerformed(evt);
            }
        });

        try {
            jFormattedTxtTelefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##) #####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jFormattedTxtTelefone.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jFormattedTxtTelefone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTxtTelefoneActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTxtMainTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTxtCPF)
                            .addComponent(jTxtNome)
                            .addComponent(jTxtRG)
                            .addComponent(jTxtDtNascimento)
                            .addComponent(jTxtTelefone))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTxtFieldRG, javax.swing.GroupLayout.DEFAULT_SIZE, 231, Short.MAX_VALUE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jFormattedTxtCPF, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                                .addComponent(jTxtFieldNome, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE))
                            .addComponent(jFormattedTxtDtNascimento)
                            .addComponent(jFormattedTxtTelefone)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jBttMarcarFuncionario)
                        .addGap(18, 18, 18)
                        .addComponent(jBttMarcarInquilino)
                        .addGap(18, 18, 18)
                        .addComponent(jBttMarcarVisitante))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jBttCancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jBttConcluir)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTxtMainTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtNome)
                    .addComponent(jTxtFieldNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtCPF)
                    .addComponent(jFormattedTxtCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtRG)
                    .addComponent(jTxtFieldRG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtDtNascimento)
                    .addComponent(jFormattedTxtDtNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtTelefone)
                    .addComponent(jFormattedTxtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBttMarcarFuncionario)
                    .addComponent(jBttMarcarInquilino)
                    .addComponent(jBttMarcarVisitante))
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBttConcluir)
                    .addComponent(jBttCancelar))
                .addContainerGap())
        );

        jFormattedTxtCPF.getAccessibleContext().setAccessibleName("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTxtFieldNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtFieldNomeActionPerformed
//
    }//GEN-LAST:event_jTxtFieldNomeActionPerformed

    private void jTxtFieldRGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtFieldRGActionPerformed
//
    }//GEN-LAST:event_jTxtFieldRGActionPerformed

    private void jBttMarcarFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBttMarcarFuncionarioActionPerformed
//
    }//GEN-LAST:event_jBttMarcarFuncionarioActionPerformed

    private void jBttMarcarInquilinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBttMarcarInquilinoActionPerformed
//
    }//GEN-LAST:event_jBttMarcarInquilinoActionPerformed

    private void jBttMarcarVisitanteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBttMarcarVisitanteActionPerformed
//
    }//GEN-LAST:event_jBttMarcarVisitanteActionPerformed

    private void jBttConcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBttConcluirActionPerformed
    try {
        String nome = jTxtFieldNome.getText().trim();
        String rg = jTxtFieldRG.getText().trim();
        String cpf = jFormattedTxtCPF.getText().replaceAll("\\D", "");
        String telefone = jFormattedTxtTelefone.getText().trim();
        String dataTexto = jFormattedTxtDtNascimento.getText().trim();

        if (nome.isEmpty() || rg.isEmpty() ||
            !jFormattedTxtCPF.isEditValid() ||
            !jFormattedTxtDtNascimento.isEditValid() ||
            !jFormattedTxtTelefone.isEditValid()) {

            JOptionPane.showMessageDialog(this, "Preencha todos os campos corretamente!");
            return;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate dataNascimento;
        try {
            dataNascimento = LocalDate.parse(dataTexto, formatter);
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Data inválida! Use o formato dd/MM/yyyy.");
            return;
        }

        String tipo = "";
        if (jBttMarcarFuncionario.isSelected()) tipo = "Funcionário";
        else if (jBttMarcarInquilino.isSelected()) tipo = "Inquilino";
        else if (jBttMarcarVisitante.isSelected()) tipo = "Visitante";
        else {
            JOptionPane.showMessageDialog(this, "Selecione um tipo de pessoa!");
            return;
        }

        Pessoa p = new Pessoa();
        p.setNome(nome);
        p.setCpf(cpf);
        p.setRg(rg);
        p.setDataNascimento(dataNascimento);
        p.setTelefone(telefone);
        p.setTipo(tipo);

        new PessoaDAO().inserir(p);

        JOptionPane.showMessageDialog(this, "Pessoa cadastrada com sucesso!");
        limparCampos();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Erro ao cadastrar pessoa: " + e.getMessage());
    }
    }//GEN-LAST:event_jBttConcluirActionPerformed

    private void jBttCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBttCancelarActionPerformed
        new Menu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jBttCancelarActionPerformed

    private void jFormattedTxtCPFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTxtCPFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTxtCPFActionPerformed

    private void jFormattedTxtDtNascimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTxtDtNascimentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTxtDtNascimentoActionPerformed

    private void jFormattedTxtTelefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTxtTelefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTxtTelefoneActionPerformed

    private void limparCampos() {
    jTxtFieldNome.setText("");
    jTxtFieldRG.setText("");
    jFormattedTxtCPF.setValue(null);
    jFormattedTxtDtNascimento.setValue(null);
    jFormattedTxtTelefone.setValue(null);
    jBttGroupTipo.clearSelection();
    jTxtFieldNome.requestFocus();
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBttCancelar;
    private javax.swing.JButton jBttConcluir;
    private javax.swing.ButtonGroup jBttGroupTipo;
    private javax.swing.JRadioButton jBttMarcarFuncionario;
    private javax.swing.JRadioButton jBttMarcarInquilino;
    private javax.swing.JRadioButton jBttMarcarVisitante;
    private javax.swing.JFormattedTextField jFormattedTxtCPF;
    private javax.swing.JFormattedTextField jFormattedTxtDtNascimento;
    private javax.swing.JFormattedTextField jFormattedTxtTelefone;
    private javax.swing.JLabel jTxtCPF;
    private javax.swing.JLabel jTxtDtNascimento;
    private javax.swing.JTextField jTxtFieldNome;
    private javax.swing.JTextField jTxtFieldRG;
    private javax.swing.JLabel jTxtMainTitulo;
    private javax.swing.JLabel jTxtNome;
    private javax.swing.JLabel jTxtRG;
    private javax.swing.JLabel jTxtTelefone;
    // End of variables declaration//GEN-END:variables
}